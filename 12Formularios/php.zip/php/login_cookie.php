<?php
    $login = $_POST['login'];
    $senha = $_POST['senha'];
    if ($login == "evaldo" and $senha == "1234"){
        setcookie("cookie_pythonwebscraping_exemplo", $login);
        echo "Login realizado com sucesso!!!";
    }else{
        echo "Login ou senha inválidos!!!";
    }
?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Olá Aluno!!!</title>
    </head>
    <body>

    </body>
</html>